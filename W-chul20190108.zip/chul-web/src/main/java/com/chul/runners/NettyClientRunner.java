package com.chul.runners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class NettyClientRunner implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(NettyClientRunner.class);

    @Override
    public void run(String... strings) throws Exception {

    }
}
