package com.chul.modules.user.service;

import com.chul.mybatisGen.pojo.User;

import java.util.List;

public interface UserService {

    public List<User> getAll();
    public User getById(int id);
    public User insert(User user);
    public int updateById(User user);
    public int deleteById(int id);

}
