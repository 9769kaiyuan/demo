package com.chul.modules.user;

import com.chul.modules.user.service.UserService;
import com.chul.mybatisGen.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserRestController {
    private static final Logger logger = LoggerFactory.getLogger(UserRestController.class);

    @Autowired
    private UserService userService;

    @RequestMapping("/list")
    @ResponseBody
    public List<User> list(){
        logger.info("进入/user/list...");
        List<User> list = new ArrayList<User>();
        try {
            list = userService.getAll();
        } catch (Exception e) {
            logger.error("", e);
        }
        return list;
    }

    @RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
    @ResponseBody
    public User get(@PathVariable(value="id") int id) {
        logger.info("进入/user/get...");
        User user = null;
        try {
            user = userService.getById(id);
        } catch (Exception e) {
            logger.error("", e);
        }
        return user;
    }

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public User insert(User user) {
        logger.info("进入/user/insert...");
        try {
            userService.insert(user);
        } catch (Exception e) {
            logger.error("", e);
            user = null;
        }
        return user;
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(User user) {
        logger.info("进入/user/update...");
        String result = "";
        try {
            int ret = userService.updateById(user);
            if (ret >= 1) {
                result = "修改成功";
            } else {
                result = "修改失败";
            }
        } catch (Exception e) {
            logger.error("", e);
            result = "修改失败";
        }

        return result;
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable(value="id") int id) {
        logger.info("进入/user/delete...");
        String result = "";
        try {
            int ret = userService.deleteById(id);
            if (ret >= 1) {
                result = "删除成功";
            } else {
                result = "删除失败";
            }
        } catch (Exception e) {
            logger.error("", e);
            result = "删除失败";
        }

        return result;
    }



}
