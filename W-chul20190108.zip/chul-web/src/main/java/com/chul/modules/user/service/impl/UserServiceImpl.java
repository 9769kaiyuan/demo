package com.chul.modules.user.service.impl;

import com.chul.modules.user.service.UserService;
import com.chul.mybatisGen.mapper.UserMapper;
import com.chul.mybatisGen.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserMapper userMapper;//报错不影响

    @Override
    public List<User> getAll() {
        return userMapper.selectAll();
    }

    @Override
    public User getById(int id) {
        User user = userMapper.selectByPrimaryKey(id);
        return user;
    }

    @Override
    public User insert(User user) {
        userMapper.insert(user);
        return user;
    }

    @Override
    public int updateById(User user) {
        return userMapper.updateByPrimaryKey(user);
    }

    @Override
    public int deleteById(int id) {
        return userMapper.deleteByPrimaryKey(id);
    }
}
