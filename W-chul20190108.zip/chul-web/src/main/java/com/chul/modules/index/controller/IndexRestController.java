package com.chul.modules.index.controller;

import com.chul.modules.index.common.IndexConstants;
import com.chul.netty.client.NettyClient;
import com.chul.netty.common.Constants;
import io.netty.channel.ChannelPromise;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/index")
public class IndexRestController {
    private static final Logger logger = LoggerFactory.getLogger(IndexRestController.class);

    @RequestMapping("/execute")
    public String executeCmd(@RequestParam("deviceId") String deviceId,
                             @RequestParam("cmd") String cmd,
                             @RequestParam("cmdType") String cmdType) {
        logger.info("executeCmd:deviceId[{}]:cmd[{}]", deviceId, cmd);
        String cmdRes = "";

        //发送在线连接查询指令
        if (NettyClient.getChannelCache()!=null) {
            String cmdReq = "";
            if ("1".equals(cmdType)) {
                cmdReq = Constants.CMD_REQUEST_SIG.replaceAll(Constants.REPLACE_CMD_MESSAGE,
                        deviceId + IndexConstants.COMMA_DELIMITER + cmd);
            } else {
                cmdReq = Constants.CMD_REQUEST_GRO.replaceAll(Constants.REPLACE_CMD_MESSAGE,
                        deviceId + IndexConstants.COMMA_DELIMITER + cmd);
            }

            logger.info("client cmd to server [{}]...", cmdReq);
            ChannelPromise promise = NettyClient.getBussinessClientHandler().sendMessage(cmdReq);
            try {
                promise.await();
            } catch (InterruptedException e) {
                logger.error("", e);
            }
            cmdRes = NettyClient.getBussinessClientHandler().getData();
            logger.info("cmd response [{}]" + cmdRes);
        }

        return "{result:ok}";
    }

}
