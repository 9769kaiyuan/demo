package com.chul.modules.index.common;

public class IndexConstants {

    public final static String COMMA_DELIMITER = ",";

}
