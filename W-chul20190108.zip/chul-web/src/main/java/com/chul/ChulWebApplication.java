package com.chul;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(value = "com")
@MapperScan(value = "com.chul.mybatisGen.mapper")
@EnableScheduling
public class ChulWebApplication {
	private static final Logger logger = LoggerFactory.getLogger(ChulWebApplication.class);

	public static ApplicationContext context = null;

	public static void main(String[] args) {
		context = SpringApplication.run(ChulWebApplication.class, args);
	}

}

