package com.chul.netty.common;

public class Constants {

    //分割符
    public final static String START_DELIMITER = "S\\|";
    public final static String BRACKET_LEFT_DELIMITER = "\\(";
    public final static String BRACKET_RIGHT_DELIMITER = "\\)";
    public final static String START_DELIMITER_STRING = "S|";
    public final static String END_DELIMITER = "|E";
    public final static String COLON_DELIMITER = ":";
    public final static String BRACKET_LEFT_DELIMITER_STRING = "(";
    public final static String BRACKET_RIGHT_DELIMITER_STRING = ")";
    public final static String COMMA_DELIMITER = ",";
    public final static String EXCLAMATORY_DELIMITER = "!";

    //标志符
    public final static String SIGN_OK = "OK";
    public final static String SIGN_CORRECT_CODE= "0";
    public final static String SIGN_NG = "NG";

    //指令替换符
    public final static String REPLACE_SIGN_CMD = "CMD";
    //设备ID替换符
    public final static String REPLACE_SIGN_DEVICEID = "DEVICEID";
    //指令详情替换符
    public final static String REPLACE_CMD_MESSAGE = "MESSAGE";
    //错误码替换符
    public final static String REPLACE_SIGN_CORRECT_MSG = "CORRECTMSG";
    //错误码替换符
    public final static String REPLACE_SIGN_ERROR_CODE = "ERRORCODE ";

    //指令集
    public final static String CMD_REG = "REG";//注册
    public final static String CMD_HET = "HET";//心跳
    public final static String CMD_LIV = "LIV";//在线连接
    public final static String CMD_SIG = "SIG";//单步指令
    public final static String CMD_GRO = "GRO";//组合指令

    /**
     * 返回成功处理结果
     * 替换 REPLACE_SIGN_CMD
     */
    public static String CMD_RESPONSE_OK = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + REPLACE_SIGN_CMD + COLON_DELIMITER + SIGN_OK + COLON_DELIMITER + SIGN_CORRECT_CODE + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;
    /**
     * 返回成功处理结果
     * 替换 REPLACE_SIGN_CMD
     */
    public static String CMD_RESPONSE_MSG_OK = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + REPLACE_SIGN_CMD + COLON_DELIMITER + SIGN_OK + COLON_DELIMITER + REPLACE_SIGN_CORRECT_MSG + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;
    /**
     * 返回失败处理结果
     * 替换 REPLACE_SIGN_CMD , REPLACE_SIGN_ERROR_CODE
     */
    public static String CMD_RESPONSE_NG = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + REPLACE_SIGN_CMD + COLON_DELIMITER + SIGN_NG + COLON_DELIMITER + REPLACE_SIGN_ERROR_CODE + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 客户端注册指令
     */
    public final static String CMD_REQUEST_REG = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + CMD_REG + COLON_DELIMITER + REPLACE_SIGN_DEVICEID + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 客户端心跳指令
     */
    public final static String CMD_REQUEST_HET = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + CMD_HET + COLON_DELIMITER + REPLACE_SIGN_DEVICEID + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 客户端在线连接指令
     */
    public final static String CMD_REQUEST_LIV = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + CMD_LIV + COLON_DELIMITER + REPLACE_SIGN_DEVICEID + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 客户端单步指令
     * REPLACE_CMD_MESSAGE ： deviceId,cmd
     */
    public final static String CMD_REQUEST_SIG = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + CMD_SIG + EXCLAMATORY_DELIMITER + REPLACE_CMD_MESSAGE + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 客户端组合指令
     * REPLACE_CMD_MESSAGE ： deviceId,cmd
     */
    public final static String CMD_REQUEST_GRO = START_DELIMITER_STRING + BRACKET_LEFT_DELIMITER_STRING + CMD_GRO + EXCLAMATORY_DELIMITER + REPLACE_CMD_MESSAGE + BRACKET_RIGHT_DELIMITER_STRING + END_DELIMITER;

    /**
     * 服务端指令
     */
    public final static String CMD_REQUEST = START_DELIMITER_STRING + REPLACE_CMD_MESSAGE + END_DELIMITER;

}
