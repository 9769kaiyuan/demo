package com.chul.netty.client.handler;

import com.chul.netty.bean.ResBean;
import com.chul.netty.client.NettyClient;
import com.chul.netty.common.Constants;
import com.chul.netty.utils.ResParseUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import io.netty.channel.SimpleChannelInboundHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BussinessClientHandler extends SimpleChannelInboundHandler<String>{
	private static final Logger log = LoggerFactory.getLogger(BussinessClientHandler.class);
	private ChannelHandlerContext ctx;
	private ChannelPromise promise;
	private String data;

	@Override  
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		//注册指令
		String regMsg = Constants.CMD_REQUEST_REG.replaceAll(Constants.REPLACE_SIGN_DEVICEID, NettyClient.getNettyConfig().getDeviceId());
		ctx.writeAndFlush(regMsg);
		log.info("client connect server success, then register to server...");
		this.ctx = ctx;

	}

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
		ResBean bean = ResParseUtil.parseRes(msg);
		if (bean==null) {
			log.error("res parse error");
			return;
		}

		if (Constants.CMD_REG.equals(bean.getCmd())) {
			if (Constants.SIGN_OK.equals(bean.getRetFlag())) {
				NettyClient.setChannelCache(ctx.channel());//缓存通道
				NettyClient.setIsChannelConnected(true);//通道建立连接标志

				log.info("client register success");
			} else {
				log.info("client register failure");
			}

		} else if (Constants.CMD_HET.equals(bean.getCmd())) {
			if (Constants.SIGN_OK.equals(bean.getRetFlag())) {
				log.info("client heartbeat success");
			} else {
				log.info("client heartbeat failure");
			}
		} else if (Constants.CMD_LIV.equals(bean.getCmd())) {
			log.info("++++++++++++" + bean.toString());
			data = bean.getRetCode();
			promise.setSuccess();

		} else if (Constants.CMD_SIG.equals(bean.getCmd())) {
			log.info("++++++++++++" + bean.toString());
			data = bean.toString();
			promise.setSuccess();
		} else if (Constants.CMD_GRO.equals(bean.getCmd())) {
			log.info("get group cmd " + bean.getRetCode());
			data = bean.getRetCode();
			promise.setSuccess();
		}
	}

	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		log.error("accidental closure of channel");
		NettyClient.setIsChannelConnected(false);
		NettyClient.setChannelCache(null);
//		super.exceptionCaught(ctx, cause);
	}

	public ChannelPromise sendMessage(Object message) {
		if (ctx == null)
			throw new IllegalStateException();
		promise = ctx.writeAndFlush(message).channel().newPromise();
		return promise;
	}

	public String getData() {
		return data;
	}

}
