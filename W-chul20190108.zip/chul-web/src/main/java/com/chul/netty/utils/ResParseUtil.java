package com.chul.netty.utils;

import com.chul.netty.bean.ResBean;
import com.chul.netty.common.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ResParseUtil {
    private static final Logger log = LoggerFactory.getLogger(ResParseUtil.class);

    public static ResBean parseRes(String res) {
        ResBean bean = null;
        try {
            if (res.indexOf(Constants.BRACKET_RIGHT_DELIMITER_STRING + Constants.BRACKET_LEFT_DELIMITER_STRING)>0) {
                //组合指令接口额外处理
                res = res.replaceAll(Constants.START_DELIMITER, "");
                bean = new ResBean(Constants.CMD_GRO, Constants.SIGN_OK, res);

            } else if (res.indexOf(Constants.BRACKET_LEFT_DELIMITER_STRING + Constants.CMD_REG)<0
                    && res.indexOf(Constants.BRACKET_LEFT_DELIMITER_STRING + Constants.CMD_HET)<0
                    && res.indexOf(Constants.BRACKET_LEFT_DELIMITER_STRING + Constants.CMD_LIV)<0
                    && res.indexOf(Constants.BRACKET_LEFT_DELIMITER_STRING + Constants.CMD_SIG)<0
                    && res.indexOf(Constants.BRACKET_LEFT_DELIMITER_STRING + Constants.CMD_GRO)<0) {
                //单步指令接口额外处理
                res = res.replaceAll(Constants.START_DELIMITER, "");
                bean = new ResBean(Constants.CMD_SIG, Constants.SIGN_OK, res);

            } else {
                res = res.replaceAll(Constants.START_DELIMITER, "")
//                        .replaceAll(Constants.END_DELIMITER, "")
                        .replaceAll(Constants.BRACKET_LEFT_DELIMITER, "")
                        .replaceAll(Constants.BRACKET_RIGHT_DELIMITER, "");
                String[] tempRes = res.split(Constants.COLON_DELIMITER);
                bean = new ResBean(tempRes[0], tempRes[1], tempRes[2]);
            }


        } catch (Exception e) {
            log.error("", e);
        }
        return bean;
    }

}
