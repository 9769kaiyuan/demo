package com.chul.server.handler;

import com.chul.bean.ReqBean;
import com.chul.common.Constants;
import com.chul.server.ChannelRepository;
import com.chul.utils.ReqParseUtil;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.ReferenceCountUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * 连接认证Handler
 * 1. 连接成功后客户端发送CommandType.AUTH指令，Sever端验证通过后返回CommandType.AUTH_BACK指令
 * 2. 处理心跳指令
 * 3. 触发下一个Handler
 * @author Ke Shanqiang
 *
 */
@Component
@Qualifier("bussinessServerHandler")
@ChannelHandler.Sharable
public class BussinessServerHandler extends ChannelInboundHandlerAdapter {
	private static final Logger log = LoggerFactory.getLogger(BussinessServerHandler.class);
	
	@Autowired
	@Qualifier("channelRepository")
	ChannelRepository channelRepository;
	
	@SuppressWarnings("deprecation")
	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		String req = (String)msg;
		ReqBean bean = ReqParseUtil.parseReq(req);
		if (bean==null) {
			log.error("req parse error");
			return;
		}

		String res = "";
		if (Constants.CMD_REG.equals(bean.getCmd())) {
			//注册
			channelRepository.put(bean.getDeviceId(), ctx.channel());
			res = Constants.CMD_RESPONSE_OK.replaceAll(Constants.REPLACE_SIGN_CMD, bean.getCmd());
			ctx.writeAndFlush(res);
			log.info("device[{}] register success", bean.getDeviceId());

		} else if (Constants.CMD_HET.equals(bean.getCmd())) {
			//心跳
			res = Constants.CMD_RESPONSE_OK.replaceAll(Constants.REPLACE_SIGN_CMD, bean.getCmd());
			ctx.writeAndFlush(res);
			log.info("device[{}] heartbeat success", bean.getDeviceId());
		}

		ReferenceCountUtil.release(msg);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		log.error("accidental closure of channel");
//		channelRepository.remove(ctx.channel().);
		ctx.close();
	}
}
