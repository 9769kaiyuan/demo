package com.chul.server;

import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Channel Manager
 * @author Ke Shanqiang
 *
 */
@Component
public class ChannelRepository {
	private final static Map<String, Channel> channelCache = new ConcurrentHashMap<String, Channel>();

	public static void put(String key, Channel value) {
		channelCache.put(key, value);
	}

	public static Channel get(String key) {
		return channelCache.get(key);
	}

	public static void remove(String key) {
		channelCache.remove(key);
	}

	public static int size() {
		return channelCache.size();
	}
}
