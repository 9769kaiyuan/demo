package com.chul.bean;

public class ReqBean {

    private String cmd;
    private String deviceId;

    public ReqBean() {
    }

    public ReqBean(String cmd, String deviceId) {
        this.cmd = cmd;
        this.deviceId = deviceId;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return "ReqBean{" +
                "cmd='" + cmd + '\'' +
                ", deviceId='" + deviceId + '\'' +
                '}';
    }
}
