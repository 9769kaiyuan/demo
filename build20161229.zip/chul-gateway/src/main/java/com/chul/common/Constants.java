package com.chul.common;

public class Constants {

    //设备ID
    public final static String DEVICE_ID = "000001111100001";

    //分割符
    public final static String START_DELIMITER = "S\\|";
    public final static String START_DELIMITER_STRING = "S|";
    public final static String END_DELIMITER = "|E";
    public final static String COLON_DELIMITER = ":";

    //标志符
    public final static String SIGN_OK = "OK";
    public final static String SIGN_CORRECT_CODE= "0";
    public final static String SIGN_NG = "NG";

    //指令替换符
    public final static String REPLACE_SIGN_CMD = "CMD";
    //错误码替换符
    public final static String REPLACE_SIGN_ERROR_CODE = "ERRORCODE ";

    //指令集
    public final static String CMD_REG = "REG";
    public final static String CMD_HET = "HET";

    /**
     * 返回成功处理结果
     * 替换 REPLACE_SIGN_CMD
     */
    public static String CMD_RESPONSE_OK = START_DELIMITER_STRING + REPLACE_SIGN_CMD + COLON_DELIMITER + SIGN_OK + COLON_DELIMITER + SIGN_CORRECT_CODE + END_DELIMITER;
    /**
     * 返回失败处理结果
     * 替换 REPLACE_SIGN_CMD , REPLACE_SIGN_ERROR_CODE
     */
    public static String CMD_RESPONSE_NG = START_DELIMITER_STRING + REPLACE_SIGN_CMD + COLON_DELIMITER + SIGN_NG + COLON_DELIMITER + REPLACE_SIGN_ERROR_CODE + END_DELIMITER;

    /**
     * 客户端注册指令
     */
    public final static String CMD_REQUEST_REG = START_DELIMITER_STRING + CMD_REG + COLON_DELIMITER + DEVICE_ID + END_DELIMITER;

    /**
     * 客户端心跳指令
     */
    public final static String CMD_REQUEST_HET = START_DELIMITER_STRING + CMD_HET + COLON_DELIMITER + DEVICE_ID + END_DELIMITER;

}
