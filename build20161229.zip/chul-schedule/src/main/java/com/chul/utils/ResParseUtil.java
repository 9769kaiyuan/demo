package com.chul.utils;

import com.chul.bean.ResBean;
import com.chul.common.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ResParseUtil {
    private static final Logger log = LoggerFactory.getLogger(ResParseUtil.class);

    public static ResBean parseRes(String res) {
        ResBean bean = null;
        try {
            res = res.replaceAll(Constants.START_DELIMITER, "")
                    .replaceAll(Constants.END_DELIMITER, "");
            String[] tempRes = res.split(Constants.COLON_DELIMITER);
            bean = new ResBean(tempRes[0], tempRes[1], tempRes[2]);

        } catch (Exception e) {
            log.error("", e);
        }
        return bean;
    }

}
