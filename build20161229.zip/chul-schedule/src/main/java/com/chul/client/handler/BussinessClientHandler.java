package com.chul.client.handler;

import com.chul.bean.ResBean;
import com.chul.client.NettyClient;
import com.chul.common.Constants;
import com.chul.utils.ResParseUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BussinessClientHandler extends SimpleChannelInboundHandler<String>{
	private static final Logger log = LoggerFactory.getLogger(BussinessClientHandler.class);

	@Override  
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		//注册指令
		ctx.writeAndFlush(Constants.CMD_REQUEST_REG);
		log.info("client connect server success, then register to server...");
	}

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
		ResBean bean = ResParseUtil.parseRes(msg);
		if (bean==null) {
			log.error("res parse error");
			return;
		}

		if (Constants.CMD_REG.equals(bean.getCmd())) {
			if (Constants.SIGN_OK.equals(bean.getRetFlag())) {
				NettyClient.setChannelCache(ctx.channel());//缓存通道
				NettyClient.setIsChannelConnected(true);//通道建立连接标志

				log.info("client register success");
			} else {
				log.info("client register failure");
			}

		} else if (Constants.CMD_HET.equals(bean.getCmd())) {
			if (Constants.SIGN_OK.equals(bean.getRetFlag())) {
				log.info("client heartbeat success");
			} else {
				log.info("client heartbeat failure");
			}
		} else if ("DEV".equals(bean.getCmd())) {
			log.info("++++++++++++" + bean.toString());
		}
	}

	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		log.error("accidental closure of channel");
		NettyClient.setIsChannelConnected(false);
		NettyClient.setChannelCache(null);
//		super.exceptionCaught(ctx, cause);
	}

}
