package com.chul.client;

import com.chul.client.handler.BussinessClientHandler;
import com.chul.common.Constants;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * netty客户端
 * @author lenovo
 *
 */
public class NettyClient {
	private static final Logger log = LoggerFactory.getLogger(NettyClient.class);

	private final static String HOST = "127.0.0.1";
	private final static int PORT = 8090;

	private static Channel channelCache = null;
	private static volatile boolean isChannelConnected = false;

	private EventLoopGroup loop = new NioEventLoopGroup();

	public void run() throws Exception {
		try {  
			doConnect(new Bootstrap(), loop);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * netty client 连接，连接失败10秒后重试连接
	 */
	public Bootstrap doConnect(Bootstrap bootstrap, EventLoopGroup eventLoopGroup) {
		try {
			if (bootstrap != null) {
				bootstrap.group(eventLoopGroup);
				bootstrap.channel(NioSocketChannel.class);
				bootstrap.option(ChannelOption.SO_KEEPALIVE, true);
				bootstrap.handler(new ChannelInitializer<SocketChannel>() {
					@Override
					public void initChannel(SocketChannel socketChannel) throws Exception {
						ChannelPipeline pipeline = socketChannel.pipeline();

						ByteBuf delimiter = Unpooled.copiedBuffer(Constants.END_DELIMITER.getBytes());
						pipeline.addLast("framer", new DelimiterBasedFrameDecoder(1024,delimiter));
						// 字符串解码 和 编码
						pipeline.addLast("decoder", new StringDecoder());
						pipeline.addLast("encoder", new StringEncoder());

						pipeline.addLast("clientHandler", new BussinessClientHandler());
					}
				});
				bootstrap.remoteAddress(HOST, PORT);
				ChannelFuture f = bootstrap.connect().addListener((ChannelFuture futureListener)->{
					final EventLoop eventLoop = futureListener.channel().eventLoop();
					if (!futureListener.isSuccess()) {
						log.warn("Failed to connect to server, try connect after 10s");
						futureListener.channel().eventLoop().schedule(() -> doConnect(new Bootstrap(), eventLoop), 10, TimeUnit.SECONDS);
					}
				});
				f.channel().closeFuture().sync();
				eventLoopGroup.shutdownGracefully();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return bootstrap;
	}

	public static Channel getChannelCache() {
		return channelCache;
	}

	public static void setChannelCache(Channel channelCache) {
		NettyClient.channelCache = channelCache;
	}

	public static boolean getIsChannelConnected() {
		return isChannelConnected;
	}

	public static void setIsChannelConnected(boolean isChannelConnected) {
		NettyClient.isChannelConnected = isChannelConnected;
	}
}
