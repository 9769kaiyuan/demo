package com.chul.bean;

public class ResBean {

    private String cmd;
    private String retFlag;
    private String retCode;

    public ResBean() {
    }

    public ResBean(String cmd, String retFlag, String retCode) {
        this.cmd = cmd;
        this.retFlag = retFlag;
        this.retCode = retCode;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getRetFlag() {
        return retFlag;
    }

    public void setRetFlag(String retFlag) {
        this.retFlag = retFlag;
    }

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    @Override
    public String toString() {
        return "ResBean{" +
                "cmd='" + cmd + '\'' +
                ", retFlag='" + retFlag + '\'' +
                ", retCode='" + retCode + '\'' +
                '}';
    }
}
