package com.chul.modules.index.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/index")
public class IndexRestController {
    private static final Logger logger = LoggerFactory.getLogger(IndexRestController.class);

    @RequestMapping("/execute")
    public String greeting(@RequestParam("deviceId") String deviceId, @RequestParam("cmd") String cmd) {
        logger.info("执行指令:deviceId[{}]:cmd[{}]", deviceId, cmd);
        return "{result:ok}";
    }

}
