
$(document).ready(function() {
    initCmd();

    $('input:radio[name="cmdRadio"]').change(function() {
        initCmd();
    });

    $("#executeForm").submit(function(e){
        execute();
    });
});

function initCmd() {
    var cmdRadios = $('input:radio[name="cmdRadio"]:checked').val();
    if (cmdRadios==1) {
        $('#singleCmdDiv').show();
        $('#groupCmdDiv').hide();
    } else {
        $('#singleCmdDiv').hide();
        $('#groupCmdDiv').show();
    }
}

function execute() {
    var cmd = "";
    var deviceId = $("#deviceId").val();
    var cmdRadios = $('input:radio[name="cmdRadio"]:checked').val();
    if (cmdRadios==1) {
        cmd = $('#singleCmd').val();
    } else {
        cmd = $('#groupCmd').val();
    }

    var req = {
        'deviceId':deviceId,
        'cmd':cmd
    };

    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8090/index/execute",
        data: {
            'deviceId':deviceId,
            'cmd':cmd
        },
        dataType: "json",
        success: function(data){
            alert(data.result);
        }

    });
}